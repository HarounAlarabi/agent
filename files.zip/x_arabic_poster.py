"""
Arabic X Thread Poster
======================
Posts a multi-tweet Arabic thread to X (Twitter) using the v2 API.
Requires tweepy and your X Developer credentials.

Install:
    pip install tweepy anthropic feedparser python-dotenv

Setup:
    Create a .env file next to this script with your credentials (see below).
"""

import os
import time
import tweepy
import feedparser
import anthropic
from dotenv import load_dotenv

load_dotenv()

# ---------------------------------------------------------------------------
# 1. CREDENTIALS  (put these in a .env file, never hardcode)
# ---------------------------------------------------------------------------
# X_API_KEY=...
# X_API_KEY_SECRET=...
# X_ACCESS_TOKEN=...
# X_ACCESS_TOKEN_SECRET=...
# ANTHROPIC_API_KEY=...

def get_x_client() -> tweepy.Client:
    return tweepy.Client(
        consumer_key=os.environ["X_API_KEY"],
        consumer_secret=os.environ["X_API_KEY_SECRET"],
        access_token=os.environ["X_ACCESS_TOKEN"],
        access_token_secret=os.environ["X_ACCESS_TOKEN_SECRET"],
    )


def get_claude_client() -> anthropic.Anthropic:
    return anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])


# ---------------------------------------------------------------------------
# 2. TRANSLATE & SPLIT INTO THREAD  (Flow 1: RSS → Arabic thread)
# ---------------------------------------------------------------------------

THREAD_PROMPT = """
You are an Arabic social-media writer. You will receive an English article summary.
Your job:
1. Write a Twitter thread of {n} tweets in natural, engaging Arabic (right-to-left).
2. Start tweet 1 with 🧵 (1/{n})
3. Number every tweet: (2/{n}), (3/{n}) ...
4. Keep each tweet under 260 characters (leave room for the source link on the last one).
5. Do NOT translate literally — rewrite naturally for Arabic readers.
6. Return ONLY a JSON array of strings, one string per tweet. No markdown, no extra text.

Article title: {title}
Article summary: {summary}
"""

def translate_to_thread(title: str, summary: str, n_tweets: int = 6) -> list[str]:
    client = get_claude_client()
    prompt = THREAD_PROMPT.format(n=n_tweets, title=title, summary=summary)
    message = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1500,
        messages=[{"role": "user", "content": prompt}],
    )
    import json
    raw = message.content[0].text.strip()
    # Strip accidental markdown fences
    raw = raw.removeprefix("```json").removeprefix("```").removesuffix("```").strip()
    tweets = json.loads(raw)
    return tweets


# ---------------------------------------------------------------------------
# 3. POST A THREAD  (chain tweets as replies to each other)
# ---------------------------------------------------------------------------

def post_thread(tweets: list[str], source_url: str | None = None) -> list[str]:
    """
    Posts tweets as a thread. Returns a list of posted tweet IDs.
    If source_url is provided it is appended to the last tweet.
    """
    client = get_x_client()
    tweet_ids: list[str] = []
    reply_to: str | None = None

    for i, text in enumerate(tweets):
        is_last = i == len(tweets) - 1
        body = text
        if is_last and source_url:
            body = f"{body}\n\n{source_url}"

        kwargs: dict = {"text": body}
        if reply_to:
            kwargs["reply"] = {"in_reply_to_tweet_id": reply_to}

        response = client.create_tweet(**kwargs)
        tweet_id = str(response.data["id"])
        tweet_ids.append(tweet_id)
        reply_to = tweet_id
        print(f"  ✓ Tweet {i+1}/{len(tweets)} posted  (id: {tweet_id})")

        if i < len(tweets) - 1:
            time.sleep(1.5)   # avoid rate-limit bursts

    return tweet_ids


# ---------------------------------------------------------------------------
# 4. RSS SCANNER  (Flow 1: monitor a feed and queue new articles)
# ---------------------------------------------------------------------------

def scan_rss(feed_url: str, max_articles: int = 5) -> list[dict]:
    """
    Parses an RSS feed and returns the latest articles as dicts:
    { title, summary, link, published }
    """
    feed = feedparser.parse(feed_url)
    articles = []
    for entry in feed.entries[:max_articles]:
        articles.append({
            "title": entry.get("title", ""),
            "summary": entry.get("summary", entry.get("description", "")),
            "link": entry.get("link", ""),
            "published": entry.get("published", ""),
        })
    return articles


# ---------------------------------------------------------------------------
# 5. REVIEW QUEUE  (simple approval loop in the terminal)
# ---------------------------------------------------------------------------

def review_and_post(article: dict, n_tweets: int = 6):
    """
    Translates one article, shows the thread for review, then posts on approval.
    """
    print(f"\n{'='*60}")
    print(f"Article: {article['title']}")
    print(f"Source:  {article['link']}")
    print(f"{'='*60}")

    print("\n⏳ Translating to Arabic thread…")
    tweets = translate_to_thread(
        title=article["title"],
        summary=article["summary"],
        n_tweets=n_tweets,
    )

    print("\n── Arabic thread preview ──")
    for i, t in enumerate(tweets, 1):
        print(f"\n[{i}/{len(tweets)}]\n{t}")

    print(f"\n── Source link: {article['link']}")

    action = input("\nPost this thread? [y = post / e = edit / s = skip]: ").strip().lower()

    if action == "y":
        print("\n🚀 Posting thread…")
        ids = post_thread(tweets, source_url=article["link"])
        print(f"\n✅ Thread posted! First tweet: https://x.com/i/web/status/{ids[0]}")

    elif action == "e":
        print("\nPaste your edited tweets one by one (empty line = done):")
        edited: list[str] = []
        while True:
            line = input(f"Tweet {len(edited)+1}: ").strip()
            if not line:
                break
            edited.append(line)
        if edited:
            print("\n🚀 Posting edited thread…")
            ids = post_thread(edited, source_url=article["link"])
            print(f"\n✅ Thread posted! https://x.com/i/web/status/{ids[0]}")
        else:
            print("No tweets entered — skipping.")

    else:
        print("Skipped.")


# ---------------------------------------------------------------------------
# 6. X KEYWORD TRACKER  (Flow 2: search X → translate → post)
# ---------------------------------------------------------------------------

REPOST_PROMPT = """
You are an Arabic social-media writer. Translate the following English tweet into
natural, engaging Arabic. Do NOT copy-paste — rewrite it to flow naturally for Arabic
readers. Keep it under 260 characters. Return ONLY the Arabic text, nothing else.

Original tweet: {tweet_text}
Original author: @{author}
"""

def translate_tweet(tweet_text: str, author: str) -> str:
    client = get_claude_client()
    prompt = REPOST_PROMPT.format(tweet_text=tweet_text, author=author)
    message = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=300,
        messages=[{"role": "user", "content": prompt}],
    )
    return message.content[0].text.strip()


def search_and_repost(keywords: list[str], max_results: int = 10):
    """
    Searches recent tweets for keywords, translates top results to Arabic,
    shows for review, then posts on approval.
    Uses X API v2 recent search (requires Basic tier or above for full access).
    """
    x = get_x_client()
    query = " OR ".join(keywords) + " -is:retweet lang:en"
    print(f"\n🔍 Searching X for: {query}")

    response = x.search_recent_tweets(
        query=query,
        max_results=max_results,
        tweet_fields=["author_id", "text", "created_at"],
        expansions=["author_id"],
        user_fields=["username"],
    )

    if not response.data:
        print("No tweets found.")
        return

    users = {u.id: u.username for u in (response.includes.get("users") or [])}

    for tweet in response.data:
        author = users.get(tweet.author_id, "unknown")
        print(f"\n{'─'*50}")
        print(f"@{author}: {tweet.text}")

        arabic = translate_tweet(tweet.text, author)
        source_mention = f"\n\n(via @{author})"
        full_post = arabic + source_mention

        print(f"\nArabic version:\n{full_post}")
        action = input("\nPost? [y / s = skip]: ").strip().lower()

        if action == "y":
            x.create_tweet(text=full_post)
            print("✅ Posted.")
        else:
            print("Skipped.")
        time.sleep(1)


# ---------------------------------------------------------------------------
# 7. MAIN — run from the command line
# ---------------------------------------------------------------------------

RSS_FEEDS = [
    "https://techcrunch.com/category/artificial-intelligence/feed",
    "https://feeds.bbci.co.uk/news/technology/rss.xml",
    # add more feeds here
]

X_KEYWORDS = ["AI", "LLM", "OpenAI", "Anthropic", "AGI", "machine learning"]


if __name__ == "__main__":
    import sys
    mode = sys.argv[1] if len(sys.argv) > 1 else "rss"

    if mode == "rss":
        # Flow 1: scan RSS feeds → translate → review → post
        print("📡 Scanning RSS feeds…")
        for feed_url in RSS_FEEDS:
            articles = scan_rss(feed_url, max_articles=3)
            for article in articles:
                review_and_post(article, n_tweets=6)

    elif mode == "x":
        # Flow 2: search X → translate → review → post
        search_and_repost(X_KEYWORDS, max_results=5)

    else:
        print("Usage: python x_arabic_poster.py [rss|x]")
